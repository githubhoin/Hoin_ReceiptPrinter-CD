Printer.exe   can be used for users to download the logo, set the code page , speed of serial port ,bluetooth name and default print fonts, also can test the printer 's printing, cash drawer, cutter, and other functions.

WIFISettingTool.exe  can be used for users to setting the wifi parameters.

LAN Port Setting Tool.exe  can be used for users to setting the LAN port parameters like IP address,gateway and default mask.
